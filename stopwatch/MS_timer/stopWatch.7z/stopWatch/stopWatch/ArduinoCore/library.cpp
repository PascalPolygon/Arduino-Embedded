/*
 * ArduinoCore.cpp
 *
 * Created: 9/10/2018 5:17:21 PM
 * Author : PascalMawabaDao
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

